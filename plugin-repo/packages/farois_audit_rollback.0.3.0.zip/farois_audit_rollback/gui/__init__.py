"""QGIS user interface components."""
